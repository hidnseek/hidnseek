USBasp Bootloader for Arduino
==========

USBaspLoader is a USB boot loader for AVR microcontrollers. Instead of requiring a separate downloader tool on the host, it emulates the popular USBasp programmer so that it can be controlled by AVRDUDE. The main documentation is located [here](https://www.obdev.at/products/vusb/usbasploader.html).


## Installation
There are two options for installing **USBasp_boot** boards in the Arduino IDE:
#### Boards Manager Installation(requires Arduino IDE version 1.6.4 or greater)
- Open the Arduino IDE.
- Open the **File > Preferences** menu item.
- Enter the following URL in **Additional Boards Manager URLs**: https://hidnseek.github.io/hidnseek/package_hidnseek_boot_index.json
- Open the **Tools > Board > Boards Manager...** menu item.
- Wait for the platform indexes to finish downloading.
- Scroll down until you see the **HidnSeek** entry and click on it.
  - Note: If you are using Arduino IDE 1.6.6 you may need to close **Boards Manager** and then reopen it before the **HidnSeek** entry will appear.
- Click **Install**.
- After installation is complete close the **Boards Manager** window.

#### Manual Installation
- Download the HidnSeek files here: https://hidnseek.github.io/hidnseek/hidnseek_manualinstall_1.1.0.zip
- Extract the .zip file.
- Move the **HidnSeek** folder into the **hardware** folder in your sketchbook folder.
- If the Arduino IDE is running then restart it.

<a id="menus"></a>
## Using the Board Menu Entries
After installing HidnSeek a new board is added to the **HidnSeek** section of the **Tools** > **Board** menu. When this board is selected additional menus will appear under the **Tools** menu.

Whenever you change a setting in these menus you need to **[Burn Bootloader](#burn)** to reconfigure your board.

#### BOD Menu
BOD stands for Brown-out Detection. This feature is intended to avoid improper operation caused by insufficient supply voltage. If the supply voltage drops below the BOD value then the microcontroller is reset.

#### Model Menu
Displays a list of board models for your **Board** menu selection.


<a id="burn"></a>
## Burning the Bootloader
To burn the bootloader, you will need an 3.3V ISP(in-system programmer). After you have connected the HidnSeek board and the programmer to your computer navigate to the **Tools** > **Burn Bootloader** command and wait until the operation completes. You will be able to upload sketches to your board using USB once the HidnSeek bootloader is installed.


<a id="upload"></a>
## Uploading Your Sketch
Upload your sketch as usual. Be sure that **USBasp** is automatically selected in the **Tools** menu.


<a id="acknowledgements"></a>
## Acknowledgements
- [Christian Starkjohann](https://www.obdev.at/products/vusb/usbasploader.html) - USBaspLoader variant for ATmegaxx8P
